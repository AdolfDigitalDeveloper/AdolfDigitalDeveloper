# DOMUtilsLibrary

Pequeña librería modular de utilidades DOM, gestos y observadores.

Principios:
- API encadenable (DOMUtilsLibrary(selector) -> instancia)
- Módulos pequeños y tree-shakeables
- Soporte pointer/touch/mouse
- Utilities reutilizables (defer, nextFrame, vh helpers)
- Componentes base (BottomSheetBase) para custom elements

Instalación:
npm install dom-utils-library

Uso rápido:
import DOMUtilsLibrary from 'dom-utils-library';
const $el = DOMUtilsLibrary('.panel');
$el.addClass('is-active').on('click', '.btn', handler);

Ver /src para implementaciones modulares:
- core/: API encadenable y helpers
- gestures/: touch, drag, swipe
- observers/: intersection/resize/mutation
- utils/: utilities reutilizables

Contribuir:
- Formatea con Prettier, lint con ESLint, escribe tests en /test (uvu).