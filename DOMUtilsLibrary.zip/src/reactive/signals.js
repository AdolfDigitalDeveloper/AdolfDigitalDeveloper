// Lightweight reactive primitives: createSignal, createEffect, createComputed and $state proxy

const EFFECT_STACK = [];

export function createSignal(initial) {
  let value = initial;
  const subs = new Set();

  function get() {
    const active = EFFECT_STACK[EFFECT_STACK.length - 1];
    if (active) subs.add(active);
    return value;
  }

  function set(newVal) {
    if (typeof newVal === 'function') {
      value = newVal(value);
    } else {
      value = newVal;
    }
    // notify
    subs.forEach(effectFn => effectFn());
    return value;
  }

  function subscribe(fn) {
    subs.add(fn);
    return () => subs.delete(fn);
  }

  return [get, set, subscribe];
}

/**
 * createEffect(fn)
 * - runs fn immediately and whenever its dependencies (signals accessed inside) change
 * - returns a disposer
 */
export function createEffect(fn) {
  const runner = () => {
    try {
      EFFECT_STACK.push(runner);
      fn();
    } finally {
      EFFECT_STACK.pop();
    }
  };
  runner();
  return () => {
    // No-op disposer for now; advanced cleanup can be implemented if needed.
  };
}

/**
 * createComputed(fn)
 * - returns a getter function that caches computed value and re-evaluates when dependencies change.
 */
export function createComputed(fn) {
  let cached;
  let dirty = true;
  const recompute = () => {
    EFFECT_STACK.push(recompute);
    try { cached = fn(); dirty = false; } finally { EFFECT_STACK.pop(); }
  };
  recompute();
  return () => {
    if (dirty) recompute();
    return cached;
  };
}

/**
 * $state(obj) -> reactive proxy for plain objects
 * - returns a proxy with a .subscribe method available via property access
 */
export function $state(initial = {}) {
  const subs = new Set();

  const notifySubs = (key, oldVal, newVal) => {
    subs.forEach(fn => {
      try { fn(key, oldVal, newVal); } catch (err) { console.error(err); }
    });
  };

  const handler = {
    get(target, prop) {
      if (prop === '__isState') return true;
      if (prop === 'subscribe') return (fn) => { subs.add(fn); return () => subs.delete(fn); };
      if (prop === 'inspect') return () => Object.assign({}, target);
      return target[prop];
    },
    set(target, prop, value) {
      const old = target[prop];
      if (old === value) { target[prop] = value; return true; }
      target[prop] = value;
      notifySubs(prop, old, value);
      return true;
    },
    deleteProperty(target, prop) {
      if (prop in target) {
        const old = target[prop];
        delete target[prop];
        notifySubs(prop, old, undefined);
      }
      return true;
    }
  };

  const proxy = new Proxy(Object.assign({}, initial), handler);
  return proxy;
}

export default {
  createSignal,
  createEffect,
  createComputed,
  $state
};