import { isString, isNode, isNodeList } from '../utils/type.js';

function normalizeInput(selectorOrNode) {
  if (!selectorOrNode) return [];
  if (isNode(selectorOrNode)) return [selectorOrNode];
  if (isNodeList(selectorOrNode)) return Array.from(selectorOrNode);
  if (Array.isArray(selectorOrNode)) return selectorOrNode.slice();
  if (isString(selectorOrNode)) {
    try { return Array.from(document.querySelectorAll(selectorOrNode)); }
    catch (e) { console.warn('Invalid selector', selectorOrNode); return []; }
  }
  return [];
}

export default class DOMUtilsCore {
  constructor(selectorOrNode) {
    this.nodes = normalizeInput(selectorOrNode);
  }

  get length() { return this.nodes.length; }
  toArray() { return this.nodes.slice(); }
  get(index = 0) { return this.nodes[index]; }
  eq(index) { return new DOMUtilsCore(this.get(index)); }

  find(selector) {
    const found = this.nodes.reduce((acc, n) => {
      if (!n) return acc;
      acc.push(...Array.from(n.querySelectorAll(selector)));
      return acc;
    }, []);
    return new DOMUtilsCore(found);
  }

  each(fn) { this.nodes.forEach((n, i) => fn.call(n, n, i)); return this; }
  map(fn) { return this.nodes.map((n, i) => fn.call(n, n, i)); }
}