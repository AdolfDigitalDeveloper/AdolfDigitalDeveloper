// src/core/dom-extensions.js
// Extend DOMUtilsCore prototype with chainable DOM helpers, event helpers, and animation/reactive integrations.

import DOMUtilsCore from './wrapper.js';
import {
  append as appendHelper,
  prepend as prependHelper,
  before as beforeHelper,
  after as afterHelper,
  css as cssHelper,
  position as positionHelper,
  offset as offsetHelper,
  clone as cloneHelper
} from './dom-helpers-extended.js';

import {
  clickOutside as clickOutsideHelper,
  longPress as longPressHelper
} from './event-helpers.js';

import {
  animate as animateHelper,
  fadeIn as fadeInHelper,
  fadeOut as fadeOutHelper
} from '../animations/animate.js';

// WeakMap to store attached listener cleanup fns per node
const NODE_LISTENERS = new WeakMap();

function ensureNodeListeners(node) {
  let m = NODE_LISTENERS.get(node);
  if (!m) {
    m = { clickOutside: [], longPress: [] };
    NODE_LISTENERS.set(node, m);
  }
  return m;
}

function getNodesFromInstance(inst) {
  return Array.isArray(inst.nodes) ? inst.nodes : [];
}

// ----------------------
// DOM helpers (chainable)
// ----------------------
if (typeof DOMUtilsCore !== 'undefined') {
  // Append content to each matched node
  DOMUtilsCore.prototype.append = function (content) {
    this.each((el) => appendHelper(el, content));
    return this;
  };

  // Prepend content to each matched node
  DOMUtilsCore.prototype.prepend = function (content) {
    this.each((el) => prependHelper(el, content));
    return this;
  };

  // Insert content before the first matched node (mirrors Element.insertBefore semantics)
  DOMUtilsCore.prototype.before = function (content) {
    const nodes = getNodesFromInstance(this);
    if (!nodes.length) return this;
    // insert before the first node
    beforeHelper(nodes[0], content);
    return this;
  };

  // Insert content after the first matched node
  DOMUtilsCore.prototype.after = function (content) {
    const nodes = getNodesFromInstance(this);
    if (!nodes.length) return this;
    afterHelper(nodes[0], content);
    return this;
  };

  /**
   * css(propOrObj[, value])
   * - getter: css('color') -> returns computed style of first node
   * - setter: css('color', 'red') or css({ color: 'red' }) -> sets for all nodes and returns this
   */
  DOMUtilsCore.prototype.css = function (propOrObj, value) {
    const first = this.get(0);
    if (!first) return this;
    // Getter
    if (typeof propOrObj === 'string' && value === undefined) {
      return cssHelper(first, propOrObj);
    }
    // Setter
    this.each((el) => cssHelper(el, propOrObj, value));
    return this;
  };

  // position() -> returns position for first node
  DOMUtilsCore.prototype.position = function () {
    const el = this.get(0);
    if (!el) return null;
    return positionHelper(el);
  };

  // offset() -> returns document offset for first node
  DOMUtilsCore.prototype.offset = function () {
    const el = this.get(0);
    if (!el) return null;
    return offsetHelper(el);
  };

  // clone(options) -> returns a new DOMUtilsCore wrapping clones
  DOMUtilsCore.prototype.clone = function (options = {}) {
    const clones = getNodesFromInstance(this).map((el) => cloneHelper(el, options));
    return new DOMUtilsCore(clones);
  };

  // ----------------------
  // Event helpers (attach/detach)
  // ----------------------

  /**
   * clickOutside(handler, options)
   * - attaches a clickOutside handler for each node in the collection
   * - stores cleanup functions per node so they can be removed with offClickOutside()
   * - returns this for chaining
   */
  DOMUtilsCore.prototype.clickOutside = function (handler, options = {}) {
    if (typeof handler !== 'function') return this;
    this.each((el) => {
      const off = clickOutsideHelper(el, handler, options);
      const store = ensureNodeListeners(el);
      store.clickOutside.push(off);
    });
    return this;
  };

  /**
   * offClickOutside()
   * - removes stored clickOutside handlers for each node
   */
  DOMUtilsCore.prototype.offClickOutside = function () {
    this.each((el) => {
      const store = NODE_LISTENERS.get(el);
      if (!store || !store.clickOutside) return;
      store.clickOutside.forEach((offFn) => {
        try { offFn && offFn(); } catch (_) {}
      });
      store.clickOutside = [];
    });
    return this;
  };

  /**
   * longPress(handler, options)
   * - attaches longPress behavior for each node and stores off fns
   */
  DOMUtilsCore.prototype.longPress = function (handler, options = {}) {
    if (typeof handler !== 'function') return this;
    this.each((el) => {
      const off = longPressHelper(el, handler, options);
      const store = ensureNodeListeners(el);
      store.longPress.push(off);
    });
    return this;
  };

  /**
   * offLongPress()
   * - removes stored longPress handlers for each node
   */
  DOMUtilsCore.prototype.offLongPress = function () {
    this.each((el) => {
      const store = NODE_LISTENERS.get(el);
      if (!store || !store.longPress) return;
      store.longPress.forEach((offFn) => {
        try { offFn && offFn(); } catch (_) {}
      });
      store.longPress = [];
    });
    return this;
  };

  // ----------------------
  // Animations
  // ----------------------

  /**
   * animate(keyframes, options)
   * - returns a Promise that resolves when all animations finish (array of Animation/results)
   * - if you prefer fire-and-forget, call .animate(...).then(() => {}) or simply ignore the promise
   */
  DOMUtilsCore.prototype.animate = function (keyframes, options = {}) {
    const nodes = getNodesFromInstance(this);
    if (!nodes.length) return Promise.resolve([]);
    const promises = nodes.map((el) => {
      try {
        return animateHelper(el, keyframes, options);
      } catch (err) {
        return Promise.reject(err);
      }
    });
    return Promise.all(promises);
  };

  DOMUtilsCore.prototype.fadeIn = function (duration = 300) {
    const nodes = getNodesFromInstance(this);
    if (!nodes.length) return Promise.resolve([]);
    return Promise.all(nodes.map((el) => fadeInHelper(el, duration)));
  };

  DOMUtilsCore.prototype.fadeOut = function (duration = 300) {
    const nodes = getNodesFromInstance(this);
    if (!nodes.length) return Promise.resolve([]);
    return Promise.all(nodes.map((el) => fadeOutHelper(el, duration)));
  };

  // convenience async aliases for chainability where user wants to await:
  // DOMUtilsLibrary('.el').fadeInAsync(200).then(...)
  DOMUtilsCore.prototype.fadeInAsync = DOMUtilsCore.prototype.fadeIn;
  DOMUtilsCore.prototype.fadeOutAsync = DOMUtilsCore.prototype.fadeOut;
}

export default DOMUtilsCore;