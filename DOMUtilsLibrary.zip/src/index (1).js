// index.js - Central exports (static imports for bundlers)
// Export core re-exports and components + ajax + new helpers

// Re-export core modules for direct imports
export * from './core/dom.js';
export * from './core/events.js';
export * from './core/helpers.js';
export * from './core/dom-helpers-extended.js';
export * from './core/event-helpers.js';

// Re-export UI modules (allow direct import { Modal } from 'dom-utils-library')
export * from './modules/modal.js';
export * from './modules/tooltip.js';
export * from './modules/tabs.js';

// Re-export AJAX and animations/reactive modules
export * from './modules/ajax.js';
export * from './animations/animate.js';
export * from './reactive/signals.js';

// Static imports to build the default/root object for the default export
import * as DOMCore from './core/dom.js';
import * as EventsCore from './core/events.js';
import * as Helpers from './core/helpers.js';
import * as DomExt from './core/dom-helpers-extended.js';
import * as EventsExt from './core/event-helpers.js';

import * as ModalModule from './modules/modal.js';
import * as TooltipModule from './modules/tooltip.js';
import * as TabsModule from './modules/tabs.js';

import * as AjaxModule from './modules/ajax.js';
import * as AnimModule from './animations/animate.js';
import * as Reactive from './reactive/signals.js';

// Default/root export (namespaced, predictable)
const DOMUtilsLibrary = {
  // Core helpers
  ...DOMCore,
  ...EventsCore,
  ...Helpers,

  // Extended DOM helpers namespace
  dom: {
    ...DomExt
  },

  // Extra event helpers
  events: {
    ...EventsExt
  },

  // Components as constructors/classes (preserve names)
  Modal: ModalModule.Modal,
  Tooltip: TooltipModule.Tooltip,
  Tabs: TabsModule.Tabs,

  // AJAX namespace
  ajax: {
    ...AjaxModule
  },

  // Animations namespace
  anim: {
    ...AnimModule
  },

  // Reactive namespace
  reactive: {
    ...Reactive
  }
};

export default DOMUtilsLibrary;
export { DOMUtilsLibrary };