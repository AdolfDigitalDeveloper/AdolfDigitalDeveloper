// src/modules/modal.js
// Improved Modal component with options, overlay handling and destroy/unbind

export class Modal {
  /**
   * @param {string|Element} selectorOrElement - selector or DOM element
   * @param {Object} options
   *  - overlaySelector: selector to find existing overlay inside modal
   *  - closeSelector: selector for close buttons inside modal
   *  - openClass: class applied when open (default: 'open')
   *  - closeOnOverlay: click overlay closes modal (default: true)
   *  - closeOnEsc: pressing Escape closes modal (default: true)
   *  - onShow/onHide: callback hooks
   */
  constructor(selectorOrElement, options = {}) {
    this.el = typeof selectorOrElement === 'string'
      ? document.querySelector(selectorOrElement)
      : selectorOrElement;
    if (!this.el) {
      throw new Error('Modal: target element not found');
    }

    this.opts = Object.assign({
      overlaySelector: '.modal-overlay',
      closeSelector: '[data-modal-close]',
      openClass: 'open',
      closeOnOverlay: true,
      closeOnEsc: true,
      onShow: null,
      onHide: null,
    }, options);

    // find or create overlay element (scoped inside modal)
    this.overlay = this.el.querySelector(this.opts.overlaySelector) || null;
    if (!this.overlay) {
      this.overlay = document.createElement('div');
      this.overlay.className = this.opts.overlaySelector.replace(/^\./, '') || 'modal-overlay';
      this.el.insertBefore(this.overlay, this.el.firstChild);
      this._overlayCreated = true;
    } else {
      this._overlayCreated = false;
    }

    // cached listeners so we can remove them on destroy
    this._listeners = [];
    this._isOpen = false;

    // Bind handlers
    this._onOverlayClick = (e) => {
      if (this.opts.closeOnOverlay) this.hide();
    };
    this._onCloseClick = (e) => {
      this.hide();
    };
    this._onKeyDown = (e) => {
      if (this.opts.closeOnEsc && e.key === 'Escape') this.hide();
    };

    // Attach delegated click listener for close buttons inside modal
    this._delegateClose = (e) => {
      const closeBtn = e.target.closest ? e.target.closest(this.opts.closeSelector) : null;
      if (closeBtn && this.el.contains(closeBtn)) {
        e.preventDefault();
        this.hide();
      }
    };

    this._init();
  }

  _init() {
    // overlay click
    this.overlay.addEventListener('click', this._onOverlayClick);
    this._listeners.push({ el: this.overlay, type: 'click', fn: this._onOverlayClick });

    // delegated close buttons
    this.el.addEventListener('click', this._delegateClose);
    this._listeners.push({ el: this.el, type: 'click', fn: this._delegateClose });

    // optionally listen for Escape key globally when open (we attach/detach on show/hide)
  }

  show() {
    if (this._isOpen) return;
    this.el.classList.add(this.opts.openClass);
    this._isOpen = true;
    // attach Esc listener
    if (this.opts.closeOnEsc) {
      window.addEventListener('keydown', this._onKeyDown);
      this._listeners.push({ el: window, type: 'keydown', fn: this._onKeyDown });
    }
    // callback
    try { typeof this.opts.onShow === 'function' && this.opts.onShow.call(this, this.el); } catch (err) { console.error(err); }
    return this;
  }

  hide() {
    if (!this._isOpen) return;
    this.el.classList.remove(this.opts.openClass);
    this._isOpen = false;
    // remove Esc listener
    try {
      window.removeEventListener('keydown', this._onKeyDown);
      this._listeners = this._listeners.filter(l => !(l.el === window && l.type === 'keydown' && l.fn === this._onKeyDown));
    } catch (_) {}
    // callback
    try { typeof this.opts.onHide === 'function' && this.opts.onHide.call(this, this.el); } catch (err) { console.error(err); }
    return this;
  }

  toggle() {
    return this._isOpen ? this.hide() : this.show();
  }

  /**
   * Completely destroy the modal instance: remove event listeners and cleanup DOM if created overlay.
   */
  destroy() {
    // remove listeners
    this._listeners.forEach(({ el, type, fn }) => {
      try { el.removeEventListener(type, fn); } catch (_) {}
    });
    this._listeners = [];

    // remove created overlay if we created it
    if (this._overlayCreated && this.overlay && this.overlay.parentNode === this.el) {
      this.el.removeChild(this.overlay);
    }

    // nullify refs
    this.el = null;
    this.overlay = null;
  }
}

export default Modal;