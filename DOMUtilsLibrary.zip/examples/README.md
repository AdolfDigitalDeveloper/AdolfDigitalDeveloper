# Examples / Playground (dist)

Instrucciones rápidas para usar los ejemplos con los bundles en `dist/`.

1. Instala dependencias y genera el build:
   - npm install
   - npm run build

   El paso `npm run build` produce los bundles en `dist/`:
   - dist/index.esm.js  (ES module build)
   - dist/index.cjs.js  (CommonJS build)
   - dist/index.umd.js  (UMD build minificado)
   - dist/bottom-sheet.esm.js  (módulo que registra el componente `<bottom-sheet>`)

2. Sirve el repositorio con un servidor estático (ejemplo):
   - npx serve .
   - o npx http-server .

3. Abre en el navegador:
   - http://localhost:5000/examples/index.html